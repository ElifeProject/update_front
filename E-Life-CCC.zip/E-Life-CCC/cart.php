<?php
$page_title = "Read Product";

$page = isset($_GET['page']) ? ($_GET['page']) : 1;
$records_per_page = 10;
$from_record_num = ($records_per_page * $page) - $records_per_page;

// include database and object files
include_once 'config/database.php';
include_once 'object/product.php';
include_once 'object/category.php';

// instantiate database and objects
$database = new Database();
$db = $database->getConnection();
 
$product = new Product($db);
$category = new Category($db);
 
// query products
$stmt = $product->readAll($from_record_num, $records_per_page);
$num = $product->countAll();

//contents
echo "<div class='right-button-margin'>";
      echo"<a href='add_product.php' class='btn btn_default' pull-right'>Create Product</a>";
echo"</div>";

if($num>0){
 
    echo "<table class='table table-hover table-responsive table-bordered'>";
        echo "<tr>";
            echo "<th>Product</th>";
            echo "<th>Price</th>";
            echo "<th>Category</th>";
        echo "</tr>";
 
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            echo "<tr>";
                echo "<td>{$Pro_name}</td>";
                echo "<td>{$price}</td>";
                echo "<td>";
                $category->Catagory_id = $cat_id;
                ///echo "$cat_id";
                    
                $category->readName();
                echo "$category->Catagory_title";
                //echo "$name";
                echo "</td>";
 
                echo "<td>";
                    // read one, edit and delete button will be here
                echo "<a href='update_product.php?id={$Pro_id}' class='btn btn-info left-margin'>
                        <span class='glyphicon glyphicon-edit'></span> Edit
                    </a>
 
                    <a delete-id='{$Pro_id}' class='btn btn-danger btn-sm remove'>
                        <span class='glyphicon glyphicon-remove'></span> Delete
                    </a>";
                echo "</td>";
 
            echo "</tr>";
 
        }
 
    echo "</table>";
 
    // the page where this paging is used
$page_url = "proindex.php?";
 
// count all products in the database to calculate total pages
$t_rows = $product->countAll();
 
// paging buttons here
include_once 'paging.php';
}
 
// tell the user there are no products
else{
    echo "<div class='alert alert-info'>No products found.</div>";
}

//include_once "layout_footer.php";
?>