<?php
class ProductImage{
 
    // database connection and table name
    private $conn;
    private $table_name = "products";
 
    // object properties
    public $id;
    public $product_id;
    public $name;
    public function __construct($db){
        $this->conn = $db;
    }
}