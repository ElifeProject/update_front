<?php
// 'cart item' object
class CartItem{
    private $conn;
    private $table_name = "cart_items";
    public $id;
    public $product_id;
    public $quantity;
    public $user_id;
    public function __construct($db){
        $this->conn = $db;
    }
}